#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 16:40:48 2017

@author: Pavan Akula, Nnaemezue Obi-eyisi, Ilya Kats
"""

from app import app
app.run(debug=False, host='0.0.0.0', port=5000)
